# Message
- You don't have to credit me but I would love to see what you create, thanks for downloading.

# License (CC0)
- "This work is licensed under a Creative Commons 0 (CC0) License"

# Support Links
If you like my stuff, consider supporting me here, thank you:
- Patreon: https://www.patreon.com/cmesias
- Itch Io: https://cmesias.itch.io/
- Twitter: https://twitter.com/Cmesias_
- Instagram: https://www.instagram.com/cmesias.itch.io/